export class Premium{
    age: number;
    lossSuffered: number;
    totalCostOfVehicle: number;
}