export class DataDto{
    status: string;
    customerId: string;
    customerName: string;
  }