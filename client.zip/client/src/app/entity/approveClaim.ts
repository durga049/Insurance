export class ApproveClaim{
    claimId: number;
    customerId: number;
    status:string;
}