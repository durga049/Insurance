export class Claim{
    date: Date;
    amount: number;
    reason: String;
    contactNo: number;
    customerId: number;
    policyId: number;
}