export class PaymentDto{
    email: string;
    amount: number;
    modeOfPayment: string;
    accountNo: number;
    contactNo:  number;
    cvv: number;
}