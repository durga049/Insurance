export class Customer{
    name: string;
    emailId: string;
    dateOfBirth: Date;
    password: string;
    contactNo: number;
    city: string;
    pincode: number;
    landmark: string;
  }
  