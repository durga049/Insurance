export class Policy{
    id: number;
    status: string;
    issueDate: Date;
    expiryDate: Date;
    duration: number;
    policyAmount: number;
    planAmount: number;
    
}