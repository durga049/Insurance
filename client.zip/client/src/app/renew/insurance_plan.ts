export class InsurancePlan{
    id: number;
    name: string;
    insurance_type: string;
    duration: number;
    amount: number;
    commision: number;
}