import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-status',
  templateUrl: './claim-status.component.html',
  styleUrls: ['./claim-status.component.css']
})
export class ClaimStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
